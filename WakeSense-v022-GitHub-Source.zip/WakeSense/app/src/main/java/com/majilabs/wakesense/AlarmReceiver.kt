package com.majilabs.wakesense

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "wakesense_alarm"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Wake-up alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "WakeSense deadline alarm"
                    enableVibration(true)
                    setBypassDnd(false)
                }
            )
        }
        val fullScreen = PendingIntent.getActivity(
            context, 4813, Intent(context, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("WakeSense alarm")
            .setContentText("It's your latest wake-up time.")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(false)
            .setOngoing(true)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .build()
        manager.notify(4812, notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!AlarmPreferences.isEnabled(context)) return
        val hour = AlarmPreferences.hour(context)
        val minute = AlarmPreferences.minute(context)
        val saved = AlarmPreferences.triggerAt(context)
        val trigger = if (saved > System.currentTimeMillis()) saved else AlarmPreferences.nextOccurrence(hour, minute)
        if (AlarmScheduler.scheduleDeadline(context, trigger)) AlarmPreferences.save(context, hour, minute, trigger)
    }
}
