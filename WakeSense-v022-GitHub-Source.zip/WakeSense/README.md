# WakeSense

**Native Android smart-alarm prototype for NoiseFit Halo Plus + Samsung Galaxy M35.**

> Current release: 0.2.2 (source prototype). This is not yet a production smart alarm and does not claim to detect live sleep stages.

## What this version does

- Requests Health Connect `READ_SLEEP` permission.
- Reads completed sleep sessions and their stage intervals from the last 14 days, with pagination.
- Shows read errors separately from an empty result (so a permission/API failure is not misreported as “0 records”).
- Uses a vertically scrollable `LazyColumn` for the entire dashboard, with stable keys and bottom content padding. This explicitly prevents the previous AI Gallery Sorter regression where a plain `Column` made the main screen impossible to scroll.
- Limits per-session stage-row rendering to 60 intervals to keep unusually large histories from making scrolling sluggish; the full session count remains visible.
- Lets the user choose a latest wake-up deadline.
- Schedules an exact Android deadline alarm, subject to Android's Alarms & reminders access.
- Uses a high-priority alarm notification and full-screen alarm activity where Android/OEM policy allows it.
- Saves the deadline locally and restores a future alarm after device reboot or app update.
- Keeps sleep records on-device; no network upload or analytics SDK is included.
- Includes GitHub Actions CI to run unit tests and build a debug APK without a local PC.

## Critical limitation: live sleep stages

NoiseFit being listed in Health Connect with sleep-write permission does **not** prove that stage records arrive during sleep. Many trackers publish the completed sleep session only after waking. WakeSense therefore reads historical sleep records for diagnostics but does not use them to trigger an early alarm. The current working alarm is the fixed latest-time fallback only.

Before enabling true smart wake-up, verify whether NoiseFit provides a genuinely live, timestamped sleep-stage feed (or another validated live signal). Do not infer current light sleep from yesterday's completed record.

## Publish and build from a phone (no PC required)

The easiest reliable phone-only route is GitHub Codespaces (availability and free usage depend on your GitHub account):

1. Create an empty GitHub repository in your phone browser.
2. In the repository, choose **Add file → Upload files** and upload `WakeSense-GitHub-Ready.zip`.
3. Commit that ZIP to the repository.
4. Open **Code → Codespaces → Create codespace on main**. In the Codespaces terminal, run:

   ```bash
   unzip WakeSense-GitHub-Ready.zip
   cp -a WakeSense/. .
   rm -rf WakeSense
   git add .
   git commit -m "Add WakeSense Android project"
   git push
   ```

5. Open the repository's **Actions** tab. The `Android CI` workflow runs unit tests and builds the debug APK.
6. Open the completed workflow run → **Artifacts** → `WakeSense-debug-apk` to download the APK to your phone.

If Codespaces is unavailable, the ZIP can still be kept as a GitHub repository file or release asset, but GitHub Actions cannot build the Android project until the ZIP's contents are extracted into the repository root. Do not commit signing keys, passwords, `local.properties`, or personal health exports.

## Build locally

- Android Studio recent stable release
- JDK 17
- Android SDK Platform 35
- Gradle 8.11.1

Run `gradle test` and `gradle :app:assembleDebug`.

## Android permissions

- Health Connect: read sleep records only.
- Alarms & reminders: exact deadline scheduling on Android 12+.
- Notifications: alarm notification on Android 13+.
- Full-screen intent: Android may restrict this access; if denied, the alarm notification remains tappable but may not automatically open over the lock screen.

Samsung battery/background restrictions and notification settings can affect alarm presentation. Test with the screen locked and battery saver settings representative of normal use.

## Scrolling regression guard

The earlier AI Gallery Sorter main screen was not vertically scrollable because it used a plain Compose `Column` without a vertical-scroll modifier. WakeSense uses one screen-level `LazyColumn` with remembered scroll state, stable record keys, and explicit content padding. Avoid replacing it with a plain `Column` unless `verticalScroll(rememberScrollState())` is added.

## Previous image-scanner project lessons applied

The earlier AI Gallery Sorter had reports of a scan ending in a crash, `0/0` matches, and no results even after lowering the threshold. WakeSense avoids analogous failure patterns by paginating Health Connect reads, separating errors from empty data, avoiding a silent `getOrDefault(emptyList())` fallback, and keeping the live-stage feature explicitly disabled until its input is proven.

## Repository structure

- `app/src/main/java/.../HealthSleepReader.kt` — Health Connect reader.
- `AlarmPreferences.kt` — persisted deadline and next-occurrence calculation.
- `AlarmScheduler.kt` — exact deadline scheduling/cancellation.
- `AlarmReceiver.kt` — alarm notification and reboot restoration.
- `AlarmActivity.kt` — audible/vibrating alarm screen.
- `MainActivity.kt` — dashboard, diagnostics and settings.
- `.github/workflows/android.yml` — cloud build and APK artifact.


## Health Connect registration and diagnostics (v0.2.2)

This version declares `android.permission.health.READ_SLEEP`, includes the Android 13-and-earlier permission-rationale activity and the Android 14+ `VIEW_PERMISSION_USAGE` alias, and checks the granted permission set again after the permission flow returns. The GitHub Actions workflow checks that the required manifest entries exist before compiling.

If WakeSense still does not appear under Health Connect → App permissions after installing this build, check the Actions artifact and installed package identity; do not assume NoiseFit's write permission grants WakeSense read access.

The app reads completed sleep sessions only. It does not currently have a verified live sleep-stage feed from NoiseFit Halo Plus, so the fixed deadline alarm remains the only active alarm trigger.
