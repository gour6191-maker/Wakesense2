package com.majilabs.wakesense

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    private const val REQUEST_CODE = 4812

    fun canScheduleExact(context: Context): Boolean {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()
    }

    fun scheduleDeadline(context: Context, triggerAtMillis: Long): Boolean {
        if (triggerAtMillis <= System.currentTimeMillis() || !canScheduleExact(context)) return false
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = alarmPendingIntent(context)
        manager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, pending), pending)
        return true
    }

    fun cancel(context: Context) {
        val pending = alarmPendingIntent(context)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
        AlarmPreferences.clear(context)
    }

    private fun alarmPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).setAction("com.majilabs.wakesense.DEADLINE_ALARM")
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
