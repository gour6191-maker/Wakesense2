package com.majilabs.wakesense

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.Color
import android.view.ViewGroup
import android.widget.LinearLayout

/**
 * Health Connect permission rationale.
 * Explains the narrow purpose and handling of sleep data.
 */
class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.rgb(18, 18, 18))
        }

        val title = TextView(this).apply {
            text = "Why WakeSense requests sleep access"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }

        val body = TextView(this).apply {
            text = "WakeSense requests read access to sleep sessions from Health Connect so it can display sleep records and help evaluate alarm features. Sleep records are read on this device and are not uploaded by WakeSense. Sleep-stage data may be delayed or historical; WakeSense does not claim to detect live light sleep unless a real-time source is independently verified."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 24)
        }

        val close = TextView(this).apply {
            text = "Close"
            textSize = 16f
            setTextColor(Color.CYAN)
            setPadding(0, 24, 0, 8)
            setOnClickListener { finish() }
        }

        root.addView(title)
        root.addView(body)
        root.addView(close)
        setContentView(root, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }
}
