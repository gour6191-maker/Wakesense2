package com.majilabs.wakesense

import android.content.Context
import java.util.Calendar

object AlarmPreferences {
    private const val FILE = "wakesense_settings"
    private const val KEY_HOUR = "deadline_hour"
    private const val KEY_MINUTE = "deadline_minute"
    private const val KEY_ENABLED = "alarm_enabled"
    private const val KEY_TRIGGER = "trigger_at"

    fun hour(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY_HOUR, 7)
    fun minute(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY_MINUTE, 0)
    fun isEnabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)
    fun triggerAt(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getLong(KEY_TRIGGER, 0L)

    fun save(context: Context, hour: Int, minute: Int, triggerAt: Long) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt(KEY_HOUR, hour).putInt(KEY_MINUTE, minute)
            .putLong(KEY_TRIGGER, triggerAt).putBoolean(KEY_ENABLED, true).apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, false).apply()
    }

    fun nextOccurrence(hour: Int, minute: Int, now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
        }
        return c.timeInMillis
    }
}
