package com.majilabs.wakesense

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.SleepSessionRecord
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.temporal.ChronoUnit

class HealthSleepReader(private val context: Context) {
    companion object {
        val permissions = setOf(HealthPermission.getReadPermission(SleepSessionRecord::class))
    }

    suspend fun readRecent(): List<SleepSessionRecord> {
        val status = HealthConnectClient.getSdkStatus(context)
        check(status == HealthConnectClient.SDK_AVAILABLE) {
            when (status) {
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> "Health Connect needs an update."
                else -> "Health Connect is not available on this device."
            }
        }
        val client = HealthConnectClient.getOrCreate(context)
        val now = Instant.now()
        val range = TimeRangeFilter.between(now.minus(14, ChronoUnit.DAYS), now)
        val all = mutableListOf<SleepSessionRecord>()
        var token: String? = null
        do {
            val response = client.readRecords(
                ReadRecordsRequest(
                    recordType = SleepSessionRecord::class,
                    timeRangeFilter = range,
                    pageSize = 500,
                    pageToken = token
                )
            )
            all.addAll(response.records)
            token = response.pageToken
        } while (token != null)
        return all.sortedByDescending { it.endTime }
    }
}
