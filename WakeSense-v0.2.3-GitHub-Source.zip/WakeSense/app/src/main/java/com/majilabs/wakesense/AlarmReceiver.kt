package com.majilabs.wakesense

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val serviceIntent = Intent(context, AlarmPlaybackService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            // Do not crash the receiver; Android/Samsung may block service startup
            // if the app is restricted. The scheduled alarm notification remains a fallback.
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(
                        AlarmPlaybackService.CHANNEL_ID,
                        "Wake-up alarm",
                        android.app.NotificationManager.IMPORTANCE_HIGH
                    )
                )
            }
            val open = android.app.PendingIntent.getActivity(
                context, 4813,
                Intent(context, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val notification = androidx.core.app.NotificationCompat.Builder(context, AlarmPlaybackService.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("WakeSense alarm")
                .setContentText("Alarm service could not start. Tap to open alarm controls.")
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
            nm.notify(AlarmPlaybackService.NOTIFICATION_ID, notification)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!AlarmPreferences.isEnabled(context)) return
        val hour = AlarmPreferences.hour(context)
        val minute = AlarmPreferences.minute(context)
        val saved = AlarmPreferences.triggerAt(context)
        val trigger = if (saved > System.currentTimeMillis()) saved else AlarmPreferences.nextOccurrence(hour, minute)
        if (AlarmScheduler.scheduleDeadline(context, trigger)) AlarmPreferences.save(context, hour, minute, trigger)
    }
}
