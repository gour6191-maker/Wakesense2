package com.majilabs.wakesense

import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WakeSenseScreen() }
    }

    @Composable
    private fun WakeSenseScreen() {
        val scope = rememberCoroutineScope()
        var status by remember { mutableStateOf("Health Connect not checked yet") }
        var error by remember { mutableStateOf<String?>(null) }
        var records by remember { mutableStateOf(emptyList<androidx.health.connect.client.records.SleepSessionRecord>()) }
        var loading by remember { mutableStateOf(false) }
        var hour by remember { mutableIntStateOf(AlarmPreferences.hour(this)) }
        var minute by remember { mutableIntStateOf(AlarmPreferences.minute(this)) }
        var message by remember { mutableStateOf(if (AlarmPreferences.isEnabled(this)) "Alarm saved" else "No alarm scheduled") }

        val permissionLauncher = rememberLauncherForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { _ ->
            // Do not trust only the activity-result payload: query Health Connect again.
            scope.launch {
                loading = true
                error = null
                try {
                    val client = HealthConnectClient.getOrCreate(this@MainActivity)
                    val actuallyGranted = client.permissionController.getGrantedPermissions()
                    if (actuallyGranted.containsAll(HealthSleepReader.permissions)) {
                        status = "Sleep permission verified. Reading recent records..."
                        records = HealthSleepReader(this@MainActivity).readRecent()
                        status = "Read ${records.size} completed sleep session(s) from the last 14 days"
                    } else {
                        status = "WakeSense still does not have sleep-read permission. Open Health Connect → App permissions → WakeSense."
                    }
                } catch (e: Exception) {
                    error = e.message ?: e::class.java.simpleName
                    status = "Could not verify or read Health Connect permission"
                } finally {
                    loading = false
                }
            }
        }

        MaterialTheme(colorScheme = darkColorScheme()) {
            Scaffold { padding ->
                // Regression guard: the entire dashboard is a LazyColumn, not a plain Column.
                // This keeps the screen vertically scrollable even when diagnostics/history grow.
                val listState = rememberLazyListState()
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Text("WakeSense", style = MaterialTheme.typography.headlineLarge)
                        Text("Smart alarm · NoiseFit Halo Plus", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("Build 0.2.0 · Deadline-safe prototype", style = MaterialTheme.typography.labelSmall)
                    }
                    item {
                        Card { Column(Modifier.padding(16.dp)) {
                            Text("Sleep data diagnostics", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Text(status)
                            if (loading) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                            error?.let { Text("Error: $it", color = MaterialTheme.colorScheme.error) }
                            Spacer(Modifier.height(8.dp))
                            Button(enabled = !loading, onClick = {
                                error = null
                                status = "Checking Health Connect..."
                                val sdk = HealthConnectClient.getSdkStatus(this@MainActivity)
                                if (sdk == HealthConnectClient.SDK_AVAILABLE) {
                                    scope.launch {
                                        loading = true
                                        try {
                                            val client = HealthConnectClient.getOrCreate(this@MainActivity)
                                            val granted = client.permissionController.getGrantedPermissions()
                                            if (granted.containsAll(HealthSleepReader.permissions)) {
                                                status = "Permission verified. Reading sleep records..."
                                                records = HealthSleepReader(this@MainActivity).readRecent()
                                                status = "Read ${records.size} completed sleep session(s) from the last 14 days"
                                            } else {
                                                status = "Requesting sleep-read permission..."
                                                permissionLauncher.launch(HealthSleepReader.permissions)
                                            }
                                        } catch (e: Exception) {
                                            error = e.message ?: e::class.java.simpleName
                                            status = "Health Connect connection failed"
                                        } finally {
                                            loading = false
                                        }
                                    }
                                } else {
                                    status = if (sdk == HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) "Update Health Connect, then retry." else "Health Connect is unavailable."
                                    runCatching { startActivity(Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")) }
                                }
                            }) { Text(if (loading) "Connecting…" else "Connect / read sleep data") }
                            Text("This reads completed historical sessions. It does not provide a verified live sleep-stage feed.", style = MaterialTheme.typography.bodySmall)
                        } }
                    }
                    item {
                        Card { Column(Modifier.padding(16.dp)) {
                            Text("Hybrid alarm", style = MaterialTheme.typography.titleLarge)
                            Text("Earliest light-sleep window: not active yet", style = MaterialTheme.typography.bodyMedium)
                            Text("Latest wake-up deadline: ${formatTime(hour, minute)}", style = MaterialTheme.typography.bodyMedium)
                            Text("Light-sleep triggering stays disabled until a real-time NoiseFit signal is verified. The deadline alarm works independently.", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(onClick = {
                                TimePickerDialog(this@MainActivity, { _, h, m -> hour = h; minute = m }, hour, minute, false).show()
                            }) { Text("Choose latest wake-up time") }
                            Button(onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 7001)
                                    message = "Grant notification permission, then tap Schedule again."
                                } else if (!AlarmScheduler.canScheduleExact(this@MainActivity)) {
                                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                                    message = "Allow Alarms & reminders, return here, then tap Schedule again."
                                } else {
                                    val trigger = AlarmPreferences.nextOccurrence(hour, minute)
                                    val ok = AlarmScheduler.scheduleDeadline(this@MainActivity, trigger)
                                    if (ok) {
                                        AlarmPreferences.save(this@MainActivity, hour, minute, trigger)
                                        message = "Deadline alarm scheduled for ${formatTime(hour, minute)}."
                                    } else message = "Could not schedule. Check exact-alarm permission and selected time."
                                }
                            }) { Text("Schedule deadline alarm") }
                            OutlinedButton(onClick = { AlarmScheduler.cancel(this@MainActivity); message = "Alarm cancelled" }) { Text("Cancel alarm") }
                            Text(message, style = MaterialTheme.typography.bodySmall)
                        } }
                    }
                    item { Text("Recent completed sleep sessions", style = MaterialTheme.typography.titleLarge) }
                    if (records.isEmpty()) item { Text("No records loaded. Sync a completed night in NoiseFit, grant sleep permission and read again.") }
                    items(records, key = { record -> record.startTime.toEpochMilli() }) { record ->
                        Card { Column(Modifier.padding(14.dp)) {
                            val fmt = DateTimeFormatter.ofPattern("dd MMM, HH:mm").withZone(ZoneId.systemDefault())
                            Text("${fmt.format(record.startTime)} – ${fmt.format(record.endTime)}", style = MaterialTheme.typography.titleMedium)
                            Text("Stage intervals: ${record.stages.size}")
                            // Bound per-card rendering so unusually verbose stage histories
                            // cannot make a single lazy-list row excessively expensive.
                            record.stages.take(60).forEachIndexed { index, stage ->
                                Text("${stageName(stage.stage)} · ${fmt.format(stage.startTime)} – ${fmt.format(stage.endTime)}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (record.stages.size > 60) {
                                Text("Showing first 60 of ${record.stages.size} stage intervals.", style = MaterialTheme.typography.labelSmall)
                            }
                        } }
                    }
                    item { Text("Privacy: sleep records are read locally and are not uploaded by WakeSense.", style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }

    private fun formatTime(hour: Int, minute: Int) = "%02d:%02d".format(hour, minute)

    private fun stageName(stage: Int): String = when (stage) {
        1 -> "Awake"; 2 -> "Sleep (unspecified)"; 3 -> "Out of bed"; 4 -> "Light"; 5 -> "Deep"; 6 -> "REM"; 7 -> "Sleep (awake in bed)"; else -> "Stage $stage"
    }
}
