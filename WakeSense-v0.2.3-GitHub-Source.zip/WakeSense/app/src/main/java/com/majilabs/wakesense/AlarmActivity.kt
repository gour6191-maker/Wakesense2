package com.majilabs.wakesense

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Wake up", style = MaterialTheme.typography.displayMedium)
                        Spacer(Modifier.height(12.dp))
                        Text("Your latest wake-up deadline has arrived.")
                        Spacer(Modifier.height(28.dp))
                        Button(onClick = { dismissAlarm() }) { Text("Dismiss alarm") }
                    }
                }
            }
        }
    }

    private fun dismissAlarm() {
        stopService(Intent(this, AlarmPlaybackService::class.java).setAction(AlarmPlaybackService.ACTION_STOP))
        (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager)
            .cancel(AlarmPlaybackService.NOTIFICATION_ID)
        AlarmPreferences.clear(this)
        finish()
    }
}
