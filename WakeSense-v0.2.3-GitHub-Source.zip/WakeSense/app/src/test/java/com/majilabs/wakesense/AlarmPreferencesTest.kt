package com.majilabs.wakesense

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar

class AlarmPreferencesTest {
    @Test fun nextOccurrenceUsesTodayWhenTimeIsStillAhead() {
        val base = Calendar.getInstance().apply { set(2026, Calendar.JANUARY, 10, 5, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val expected = Calendar.getInstance().apply { timeInMillis = base; set(Calendar.HOUR_OF_DAY, 7); set(Calendar.MINUTE, 15) }.timeInMillis
        assertEquals(expected, AlarmPreferences.nextOccurrence(7, 15, base))
    }

    @Test fun nextOccurrenceMovesToTomorrowWhenDeadlinePassed() {
        val base = Calendar.getInstance().apply { set(2026, Calendar.JANUARY, 10, 8, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val expected = Calendar.getInstance().apply { timeInMillis = base; add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 7); set(Calendar.MINUTE, 15) }.timeInMillis
        assertEquals(expected, AlarmPreferences.nextOccurrence(7, 15, base))
    }
}
